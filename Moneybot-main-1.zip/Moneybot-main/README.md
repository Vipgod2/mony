# Save Restricted Bot

*A Telegram Bot, Which can send you restricted content by it's post link*

---

## Variables

- `HASH` Your API Hash from my.telegram.org
- `ID` Your API ID from my.telegram.org
- `TOKEN` Your bot token from @BotFather
- `STRING` Your session string, for examplpe you can get it at [replit.com](https://replit.com/@ErichDaniken/Generate-Telegram-String-Session)

---

# Usage

__FOR PUBLIC CHATS__

_just send post/s link_

<br>

__FOR PRIVATE CHATS__

_first send invite link of the chat (unnecessary if the account of string session already member of the chat)
then send post/s link_
